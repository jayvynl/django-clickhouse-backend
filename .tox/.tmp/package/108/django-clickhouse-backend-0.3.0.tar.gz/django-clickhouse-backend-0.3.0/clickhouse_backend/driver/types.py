Binary = bytes
