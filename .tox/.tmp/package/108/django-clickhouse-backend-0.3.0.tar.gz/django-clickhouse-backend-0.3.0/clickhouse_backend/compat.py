import django

dj32 = (3, 2) <= django.VERSION < (4, )
dj4 = (4, ) <= django.VERSION < (5, )
dj_ge4 = django.VERSION >= (4, )
dj_ge41 = django.VERSION >= (4, 1)
