class BaseIDWorker:
    def get_id(self):
        raise NotImplementedError()
